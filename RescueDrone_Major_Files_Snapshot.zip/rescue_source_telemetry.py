"""Record feed telemetry locally and sync it to Tiger Data on demand."""

import argparse
import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from time import monotonic
from uuid import uuid4

DB = Path(__file__).resolve().with_name("rescue_source_telemetry.sqlite3")


def connect():
    db = sqlite3.connect(DB)
    db.execute("""
        CREATE TABLE IF NOT EXISTS source_samples (
            event_id TEXT PRIMARY KEY,
            recorded_at TEXT NOT NULL,
            session_id TEXT NOT NULL,
            source_id TEXT NOT NULL,
            status TEXT NOT NULL,
            frames INTEGER NOT NULL,
            last_frame_at TEXT,
            review_type TEXT,
            synced INTEGER NOT NULL DEFAULT 0
        )
    """)
    return db


def latest_sources():
    with closing(connect()) as db:
        db.row_factory = sqlite3.Row
        return [dict(row) for row in db.execute("""
            WITH ranked AS (
                SELECT *, ROW_NUMBER() OVER (
                    PARTITION BY source_id ORDER BY rowid DESC
                ) AS position FROM source_samples
                WHERE status <> 'review'
            )
            SELECT source_id, session_id, status, frames, last_frame_at
            FROM ranked WHERE position = 1 ORDER BY source_id
        """)]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class FeedTelemetry:
    def __init__(self, source_id):
        self.source_id = source_id
        self.session_id = uuid4().hex
        self.last_frame_at = None
        self.frames = 0
        self.next_sample = 0
        self.warned = False

    def record(self, status, review_type=None):
        try:
            with closing(connect()) as db, db:
                db.execute("""
                    INSERT INTO source_samples VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """, (uuid4().hex, utc_now(), self.session_id, self.source_id,
                      status, self.frames, self.last_frame_at, review_type))
        except sqlite3.Error as error:
            if not self.warned:
                print(f"Source telemetry unavailable: {error}", flush=True)
                self.warned = True

    def frame(self):
        self.frames += 1
        self.last_frame_at = utc_now()
        now = monotonic()
        if now >= self.next_sample:
            self.record("receiving")
            self.next_sample = now + 2


def sync_to_tiger():
    import psycopg

    dsn = os.environ.get("RESCUEDRONE_TIGER_DSN")
    if not dsn:
        raise SystemExit("Set RESCUEDRONE_TIGER_DSN to your Tiger Data connection string.")

    with closing(connect()) as db, db:
        rows = db.execute("""
            SELECT event_id, recorded_at, session_id, source_id, status,
                   frames, last_frame_at, review_type
            FROM source_samples WHERE synced = 0 ORDER BY rowid LIMIT 1000
        """).fetchall()
        if not rows:
            return 0
        with psycopg.connect(dsn, connect_timeout=5, sslmode="require",
                             options="-c statement_timeout=15000") as cloud:
            cloud.execute("""
                CREATE TABLE IF NOT EXISTS rescuedrone_source_samples (
                    event_id text NOT NULL,
                    recorded_at timestamptz NOT NULL,
                    session_id text NOT NULL,
                    source_id text NOT NULL,
                    status text NOT NULL,
                    frames bigint NOT NULL,
                    last_frame_at timestamptz,
                    review_type text,
                    PRIMARY KEY (recorded_at, event_id)
                )
            """)
            cloud.execute("""
                SELECT create_hypertable('rescuedrone_source_samples', 'recorded_at',
                                         if_not_exists => TRUE)
            """)
            with cloud.cursor() as cursor:
                cursor.executemany("""
                    INSERT INTO rescuedrone_source_samples
                    VALUES (%s, %s::timestamptz, %s, %s, %s, %s, %s::timestamptz, %s)
                    ON CONFLICT (recorded_at, event_id) DO NOTHING
                """, rows)
        db.executemany("UPDATE source_samples SET synced = 1 WHERE event_id = ?",
                       [(row[0],) for row in rows])
        return len(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["sync"])
    parser.parse_args()
    try:
        while count := sync_to_tiger():
            print(f"Tiger Data sync acknowledged {count} telemetry samples.", flush=True)
    except ImportError:
        raise SystemExit('Install the Tiger Data driver with python -m pip install "psycopg[binary]".')
    except Exception as error:
        raise SystemExit(f"Tiger Data sync stopped ({type(error).__name__}). Local samples remain queued.")
