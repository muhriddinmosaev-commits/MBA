from time import sleep
from rescue_source_telemetry import FeedTelemetry
from rescue_incident_store import save_incident
import json
from datetime import datetime, timezone
import sys
from uuid import uuid4
from collections import deque
from pathlib import Path

import cv2
import numpy as np
from ultralytics import YOLO

clip = Path(sys.argv[1])
model = YOLO("yolo26n-pose.pt")
video = cv2.VideoCapture(str(clip))

stride = 3
transition_limit = 1.0
horizontal_hold = 1.0
upright_history = {}
down_since = {}
rapid_candidates = {}
view_lost_reported = set()
interrupted_holds = {}
dispatch = "--dispatch" in sys.argv[2:]
long_gap = "--long-gap" in sys.argv[2:]
walkway_crop = "--walkway-crop" in sys.argv[2:]
review_min_drop = 0.65 if long_gap else 0.90
review_max_gap = 1.0 if long_gap else 0.70
rapid_evidence = {}
hold_evidence = {}

telemetry = FeedTelemetry("replay-drone-2")

def publish_review(event, *, image=None, evidence=None):
    if not dispatch:
        return

    run_id = uuid4().hex
    if image is not None:
        evidence = f"fall_review_{run_id[:8]}.jpg"
        if not cv2.imwrite(evidence, image):
            raise SystemExit("Could not save the review snapshot.")

    event.update(simulation=True, run_id=run_id, video=clip.name, evidence=evidence)
    event["location"] = {"kind": "unavailable"}
    if "--demo-location" in sys.argv[2:]:
        demo = json.loads(Path("simulated_incident.json").read_text(encoding="utf-8-sig"))
        if demo.get("simulation") is not True:
            raise SystemExit("Expected simulated coordinates.")
        event["location"] = {
            "kind": "simulated",
            "latitude": demo.get("latitude"),
            "longitude": demo.get("longitude"),
        }
    event["source_id"] = telemetry.source_id
    event["source_session_id"] = telemetry.session_id
    if event["type"] != "no_detection":
        telemetry.record("review", event["type"])
    pending = Path(f"cliff_track_alert.{run_id}.tmp")
    if event["type"] != "no_detection":
        event["received_at_utc"] = datetime.now(timezone.utc).isoformat()
        save_incident(event)
    pending.write_text(json.dumps(event, indent=2), encoding="utf-8")
    for attempt in range(20):
        try:
            pending.replace("cliff_track_alert.json")
            break
        except PermissionError:
            if attempt == 19:
                raise
            sleep(0.1)
    print(f"Dispatcher updated | Run {run_id[:8]}", flush=True)

def publish_view_lost(event_type, track_id, review_time, last_seen, snapshots):
    if not dispatch:
        return

    publish_review({
        "type": event_type,
        "track_id": track_id,
        "review_time_s": round(review_time, 2),
        "last_pose_time_s": round(last_seen, 2),
    }, image=snapshots[track_id])

first_seen = {}
recent_descents = {}

def box_overlap(a, b):
    overlap = np.maximum(0, np.minimum(a[2:], b[2:]) - np.maximum(a[:2], b[:2]))
    intersection = float(np.prod(overlap))
    union = float(np.prod(a[2:] - a[:2]) + np.prod(b[2:] - b[:2])) - intersection
    return intersection / union if union > 0 else 0.0
frame_number = 0
samples = 0
alert = None

def read_torso(points, scores):
    # Use the clearer side when the other shoulder or hip is hidden.
    sides = [(5, 11), (6, 12)]
    shoulder, hip = max(sides, key=lambda pair: min(scores[list(pair)]))
    if min(scores[shoulder], scores[hip]) < 0.45:
        return None

    dx, dy = points[hip] - points[shoulder]
    size = float(np.hypot(dx, dy))
    if size < 20:
        return None

    if dy > 1.5 * abs(dx):
        posture = "upright"
    elif abs(dy) <= 0.6 * abs(dx):
        posture = "horizontal"
    else:
        posture = "intermediate"

    center_y = float((points[shoulder, 1] + points[hip, 1]) / 2)
    return posture, center_y, size

telemetry.record("starting")
feed_status = "error"
try:
    fps = video.get(cv2.CAP_PROP_FPS)
    if not video.isOpened() or fps <= 0:
        raise SystemExit(f"Could not read the video or its frame rate: {clip}")

    print(f"Testing {clip.name}...", flush=True)

    while True:
        ok, frame = video.read()
        if not ok:
            break

        telemetry.frame()
        frame_number += 1
        if frame_number % stride:
            continue

        samples += 1
        seconds = (frame_number - 1) / fps
        if walkway_crop:
            frame = frame[int(frame.shape[0] * 0.45):, :]

        result = model.track(
            frame, persist=True, tracker="bytetrack.yaml",
            imgsz=960, conf=0.25, device=0, verbose=False,
        )[0]

        valid_ids = set()
        horizontal_ids = set()
        new_horizontal = {}

        if result.boxes.id is not None and result.keypoints is not None:
            points = result.keypoints.xy.cpu().numpy()
            scores = result.keypoints.conf.cpu().numpy()
            ids = result.boxes.id.int().cpu().tolist()

            for row, track_id in enumerate(ids):
                torso = read_torso(points[row], scores[row])
                if torso is None:
                    continue

                valid_ids.add(track_id)
                posture, center_y, size = torso
                history = upright_history.setdefault(track_id, deque())
                while history and seconds - history[0][0] > transition_limit:
                    history.popleft()

                if track_id in rapid_candidates:
                    rapid_at, _ = rapid_candidates[track_id]
                    rapid_candidates[track_id] = (rapid_at, seconds)

                if posture != "upright" and any(
                    center_y - old_y >= 1.5 * old_size
                    for _, old_y, old_size in history
                ):
                    rapid_candidates[track_id] = (seconds, seconds)

                first_seen.setdefault(track_id, seconds)
                box = result.boxes.xyxy[row].cpu().numpy()
                drop = max(
                    ((center_y - old_y) / old_size for _, old_y, old_size in history),
                    default=0.0,
                )

                if drop >= review_min_drop:
                    recent_descents[track_id] = (seconds, box, result.plot())
                else:
                    recent_descents.pop(track_id, None)

                if posture == "horizontal" and seconds - first_seen[track_id] <= 0.25:
                    new_horizontal[track_id] = box

                if dispatch and track_id in rapid_candidates:
                    rapid_evidence[track_id] = result.plot()
                if posture == "upright":
                    history.append((seconds, center_y, size))
                elif posture == "horizontal":
                    horizontal_ids.add(track_id)
                    if track_id not in down_since and any(
                        center_y - earlier_y >= 0.35 * earlier_size
                        for _, earlier_y, earlier_size in history
                    ):
                        down_since[track_id] = seconds

                    if dispatch and track_id in down_since:
                        hold_evidence[track_id] = result.plot()
                    if track_id in down_since and seconds - down_since[track_id] >= horizontal_hold:
                        alert = (track_id, seconds)
                        break

        for candidate_id, (rapid_at, last_seen) in list(rapid_candidates.items()):
            if seconds - rapid_at > 1.2:
                del rapid_candidates[candidate_id]
                continue

            if candidate_id not in valid_ids and seconds - last_seen >= 0.35:
                if candidate_id not in view_lost_reported:
                    print(
                        f"REVIEW | {clip.name} | Rapid descent observed - View lost"
                        f" | Track {candidate_id} | {seconds:.2f} s"
                        f" | Last usable pose {last_seen:.2f} s",
                        flush=True,
                    )
                    publish_view_lost(
                        "rapid_descent_view_lost", candidate_id,
                        seconds, last_seen, rapid_evidence,
                    )
                    view_lost_reported.add(candidate_id)
                del rapid_candidates[candidate_id]

        # Remember the last usable horizontal pose even after the hold resets.
        for track_id in valid_ids:
            if track_id in horizontal_ids and track_id in down_since:
                interrupted_holds[track_id] = seconds
            else:
                interrupted_holds.pop(track_id, None)

        for track_id, last_seen in list(interrupted_holds.items()):
            if track_id in valid_ids or seconds - last_seen < 0.35:
                continue

            if track_id not in view_lost_reported:
                print(
                    f"REVIEW | {clip.name} | Horizontal hold interrupted - View lost"
                    f" | Track {track_id} | {seconds:.2f} s"
                    f" | Last usable pose {last_seen:.2f} s",
                    flush=True,
                )
                publish_view_lost(
                    "horizontal_hold_interrupted", track_id,
                    seconds, last_seen, hold_evidence,
                )
                view_lost_reported.add(track_id)

            del interrupted_holds[track_id]

        recent_descents = {
            track_id: observation
            for track_id, observation in recent_descents.items()
            if seconds - observation[0] <= review_max_gap
        }

        matches = [
            (old_id, new_id)
            for old_id, (last_seen, old_box, _) in recent_descents.items()
            if old_id not in valid_ids
            and old_id not in view_lost_reported
            and seconds - last_seen >= 0.20
            for new_id, new_box in new_horizontal.items()
            if new_id != old_id
            and new_id not in view_lost_reported
            and box_overlap(old_box, new_box) >= 0.15
        ]

        if len(matches) == 1:
            old_id, new_id = matches[0]
            last_seen, _, before = recent_descents.pop(old_id)
            after = result.plot()

            for image, timestamp in ((before, last_seen), (after, seconds)):
                cv2.putText(
                    image, f"{timestamp:.2f} s", (12, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2,
                )

            evidence = f"{clip.stem}_track_interrupted.jpg"
            if not cv2.imwrite(evidence, cv2.hconcat([before, after])):
                raise SystemExit("Could not save the before-and-after snapshots.")

            print(
                f"REVIEW | {clip.name} | Possible fall - Track interrupted"
                f" | IDs {old_id} to {new_id} | {seconds:.2f} s"
                f" | Gap {seconds - last_seen:.2f} s | Evidence: {evidence}",
                flush=True,
            )
            publish_review({
                "type": "fall_track_interrupted",
                "old_track_id": old_id,
                "new_track_id": new_id,
                "before_time_s": round(last_seen, 2),
                "after_time_s": round(seconds, 2),
                "gap_s": round(seconds - last_seen, 2),
            }, image=cv2.hconcat([before, after]))
            view_lost_reported.update((old_id, new_id))

        rapid_evidence = {k: v for k, v in rapid_evidence.items() if k in rapid_candidates}
        hold_evidence = {k: v for k, v in hold_evidence.items() if k in interrupted_holds}
        upright_history = {k: v for k, v in upright_history.items() if k in valid_ids}
        down_since = {k: v for k, v in down_since.items() if k in horizontal_ids}

        if alert is not None:
            break
    feed_status = "finished" if samples else "no samples"
finally:
    telemetry.record(feed_status)
    video.release()

if not samples:
    raise SystemExit("No sampled frames could be read.")

if alert is None:
    print(f"RESULT | {clip.name} | No possible-fall alert | {samples} samples")
else:
    track_id, seconds = alert
    print(f"RESULT | {clip.name} | Possible fall | Track {track_id} | {seconds:.2f} s")







