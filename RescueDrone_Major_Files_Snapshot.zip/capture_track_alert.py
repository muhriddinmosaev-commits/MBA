﻿import json
import sys
from uuid import uuid4
from pathlib import Path

import cv2
from ultralytics import YOLO

clip = Path(sys.argv[1] if len(sys.argv) > 1 else "cliff_test.mp4")
weights = Path("AerialPerson-YOLO26l.pt")
for path in (clip, weights):
    if not path.is_file():
        raise SystemExit(f"Missing file: {path.resolve()}")

model = YOLO(str(weights))
video = cv2.VideoCapture(str(clip))
if not video.isOpened():
    raise SystemExit(f"Could not open {clip}")

fps = video.get(cv2.CAP_PROP_FPS)
frame = 0
streaks = {}
alert = None

try:
    while True:
        ok, image = video.read()
        if not ok:
            break

        frame += 1
        if frame % 3:
            continue

        result = model.track(
            image, persist=True, tracker="bytetrack.yaml",
            imgsz=1280, conf=0.25, device=sys.argv[2] if len(sys.argv) > 2 else "cpu", verbose=False,
        )[0]

        current = {}
        candidates = []
        if result.boxes.id is not None:
            for box in result.boxes:
                if result.names[int(box.cls.item())] != "person":
                    continue
                track_id = int(box.id.item())
                current[track_id] = streaks.get(track_id, 0) + 1
                if current[track_id] >= 10:
                    candidates.append((box.conf.item(), track_id, box))

        streaks = current
        if not candidates:
            continue

        confidence, track_id, box = max(candidates, key=lambda item: item[0])
        x1, y1, x2, y2 = box.xyxy[0].tolist()
        evidence = image.copy()
        cv2.rectangle(evidence, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 3)
        cv2.putText(
            evidence, f"Track {track_id} | {confidence:.2f}",
            (int(x1), max(25, int(y1) - 8)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2,
        )

        if not cv2.imwrite("cliff_track_evidence.jpg", evidence):
            raise SystemExit("Could not save cliff_track_evidence.jpg")

        alert = {
            "type": "person_spotted",
            "simulation": True,
            "run_id": uuid4().hex,
            "video": clip.name,
            "frame": frame,
            "estimated_seconds_from_start": round((frame - 1) / fps, 3) if fps > 0 else None,
            "track_id": track_id,
            "consecutive_sampled_frames": streaks[track_id],
            "confidence": round(confidence, 3),
            "latitude": None,
            "longitude": None,
            "evidence": "cliff_track_evidence.jpg",
        }
        Path("cliff_track_alert.json").write_text(
            json.dumps(alert, indent=2), encoding="utf-8"
        )
        break
finally:
    video.release()

if alert is None:
    result = {
        "type": "no_detection",
        "simulation": True,
        "run_id": uuid4().hex,
        "video": clip.name,
    }
    pending = Path("cliff_track_alert.json.tmp")
    pending.write_text(json.dumps(result, indent=2), encoding="utf-8")
    pending.replace("cliff_track_alert.json")
    print(json.dumps(result, indent=2))
else:
    print(json.dumps(alert, indent=2))
    print("Saved cliff_track_alert.json and cliff_track_evidence.jpg")




