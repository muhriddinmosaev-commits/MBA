# RescueDrone source snapshot

These are the copies previously shared in chat. Files in this snapshot can predate changes on the Windows PC.

## Included

- rescue_dispatcher_server.py
- dispatcher_test.html
- fall_review_replay.py
- capture_track_alert.py
- rescue_incident_store.py
- rescue_source_telemetry.py
- rescue_incident_ai.py
- gemini_movement_test.py
- dispatcher_diagnostics.html
- simulated_incident.json
- rescue_matlab_report.png

## Missing from this snapshot

- samsung_live_fall_review.py
- samsung_live_viewer.html
- drone_viewer.html
- rescue_gemini_audio.py
- rescue_demo_pin.py
- rescue_police_units.py
- RescueDrone_ResponderDemo.slx
- README.md
- Start-RescueDrone.ps1
- Open-RescueDrone.cmd
- rescue_two_feed_timeline.png
- rescue_stateflow_workflow.png

## Export the current package

Extract Export-RescueDrone-MajorFiles.ps1 into C:\Users\muhri\RescueDrone, then run it from PowerShell. It reads the source files already on the PC and places a new ZIP on the Desktop. It stops and lists any missing major file.
