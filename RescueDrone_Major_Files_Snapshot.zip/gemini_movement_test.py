﻿
import base64
import json
import os
import sys
from time import perf_counter
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import cv2

key = os.environ.get("GEMINI_API_KEY")
if not key:
    raise SystemExit("Set GEMINI_API_KEY in this PowerShell tab first.")

video = cv2.VideoCapture(sys.argv[1])
parts = [{
    "text": (
        "Review the following timestamped frames in order. Describe observable "
        "movement only. Consider ordinary movements such as sitting or lowering "
        "oneself, a stumble with recovery, and a possible fall. If the transition "
        "or outcome is unclear, use unknown. Report 'got_up' only if the person "
        "is visibly upright again after going down. If a timestamp cannot be "
        "estimated, use null. Do not infer injury, consciousness, or intent."
    )
}]
samples = 0

try:
    fps = video.get(cv2.CAP_PROP_FPS)
    if not video.isOpened() or fps <= 0:
        raise SystemExit("Could not open the selected clip.")

    stride = max(1, round(fps / 3))
    index = 0
    while True:
        ok, frame = video.read()
        if not ok:
            break

        if index % stride == 0:
            ok, jpeg = cv2.imencode(".jpg", frame)
            if not ok:
                raise SystemExit("Could not encode a video frame.")

            parts.extend([
                {"text": f"Frame at {index / fps:.2f} seconds"},
                {"inlineData": {
                    "mimeType": "image/jpeg",
                    "data": base64.b64encode(jpeg.tobytes()).decode("ascii"),
                }},
            ])
            samples += 1
        index += 1
finally:
    video.release()

if not samples:
    raise SystemExit("The clip had no readable frames.")

schema = {
    "type": "object",
    "properties": {
        "movement": {"type": "string", "enum": [
            "ordinary_movement", "controlled_descent",
            "stumble_with_recovery", "possible_fall", "unclear",
        ]},
        "outcome": {"type": "string", "enum": [
            "stayed_upright", "got_up", "remained_down_until_clip_end",
            "view_lost", "unknown",
        ]},
        "approx_event_time_s": {"type": ["number", "null"]},
        "evidence": {"type": "string"},
        "view_limitations": {"type": "string"},
    },
    "required": [
        "movement", "outcome", "approx_event_time_s", "evidence", "view_limitations"
    ],
}

payload = {
    "contents": [{"parts": parts}],
    "generationConfig": {
        "responseMimeType": "application/json",
        "responseJsonSchema": schema,
    },
}

model = "gemini-3.5-flash"
request = Request(
    f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
    data=json.dumps(payload).encode("utf-8"),
    headers={"Content-Type": "application/json", "x-goog-api-key": key},
)

print(f"Sending {samples} frames from {sys.argv[1]} to Gemini...", flush=True)
started = perf_counter()
try:
    with urlopen(request, timeout=90) as response:
        result = json.load(response)
except HTTPError as error:
    detail = json.loads(error.read().decode("utf-8", errors="replace"))
    message = detail.get("error", {}).get("message", "Request failed.")
    raise SystemExit(f"Gemini HTTP {error.code}: {message.replace(key, '[redacted]')}")
except (URLError, TimeoutError) as error:
    raise SystemExit(f"Gemini connection failed: {error}")

candidates = result.get("candidates") or []
if not candidates:
    raise SystemExit("Gemini returned no assessment.")

answer = "".join(
    part.get("text", "")
    for part in candidates[0].get("content", {}).get("parts", [])
    if not part.get("thought")
)
if not answer:
    raise SystemExit(f"Gemini returned no assessment: {candidates[0].get('finishReason')}")

print(json.dumps(json.loads(answer), indent=2))
print(f"Gemini response time: {perf_counter() - started:.1f} seconds")

