﻿import json
import re
import sqlite3
import subprocess
import time
from contextlib import closing
from urllib.parse import parse_qs, urlsplit

from rescue_incident_store import DB, ROOT, get_incident

PUBLIC_CLIPS = {"ur_fall_03_color.mp4", "ur_fall_06_color.mp4"}


def incident_ai(handler, origin, *, start=False):
    if start and handler.headers.get("Origin") != origin:
        handler.send_error(403)
        return

    run_id = parse_qs(urlsplit(handler.path).query).get("run_id", [""])[0]
    if not re.fullmatch(r"[a-f0-9]{32}", run_id):
        handler.send_error(400, "Invalid run ID")
        return

    incident = get_incident(run_id)
    if not incident or incident.get("video") not in PUBLIC_CLIPS:
        handler.send_json({"state": "unavailable"})
        return

    now = time.time()
    with closing(sqlite3.connect(DB)) as db, db:
        db.execute("""CREATE TABLE IF NOT EXISTS incident_ai (
            run_id TEXT PRIMARY KEY,
            state TEXT NOT NULL,
            updated_at REAL NOT NULL,
            payload TEXT
        )""")
        row = db.execute(
            "SELECT state, updated_at, payload FROM incident_ai WHERE run_id = ?",
            (run_id,),
        ).fetchone()

        if row and row[0] == "ready":
            handler.send_json({"state": "ready", "assessment": json.loads(row[2])})
            return
        if row and row[0] == "running" and now - row[1] < 150:
            handler.send_json({"state": "running"})
            return
        if not start:
            handler.send_json({"state": "failed" if row else "available"})
            return

        # Reserve this run before starting an API request.
        reserved = db.execute(
            """INSERT INTO incident_ai VALUES (?, 'running', ?, NULL)
               ON CONFLICT(run_id) DO UPDATE SET
                 state = 'running', updated_at = excluded.updated_at, payload = NULL
               WHERE incident_ai.state = 'failed'
                  OR (incident_ai.state = 'running' AND incident_ai.updated_at <= ?)""",
            (run_id, now, now - 150),
        ).rowcount

    if not reserved:
        handler.send_json({"state": "running"})
        return

    gpu_python = ROOT / ".venv-gpu" / "Scripts" / "python.exe"
    try:
        result = subprocess.run(
            [str(gpu_python), "gemini_movement_test.py", incident["video"]],
            cwd=ROOT, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=115, check=True,
        )
        start_of_json = result.stdout.find("{")
        if start_of_json < 0:
            raise ValueError("No assessment returned")
        assessment, _ = json.JSONDecoder().raw_decode(result.stdout[start_of_json:])
        required = {"movement", "outcome", "approx_event_time_s", "evidence", "view_limitations"}
        if not isinstance(assessment, dict) or not required.issubset(assessment):
            raise ValueError("Incomplete assessment")
        state, payload = "ready", json.dumps(assessment)
    except (OSError, subprocess.SubprocessError, ValueError):
        state, payload = "failed", None

    with closing(sqlite3.connect(DB)) as db, db:
        db.execute(
            "UPDATE incident_ai SET state = ?, payload = ? WHERE run_id = ?",
            (state, payload, run_id),
        )

    handler.send_json({"state": state, "assessment": json.loads(payload) if payload else None})
