import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from rescue_source_telemetry import latest_sources
from rescue_incident_ai import incident_ai
from urllib.parse import urlsplit
from rescue_incident_store import history_text as sqlite_fall_history
from rescue_incident_store import get_incident as sqlite_get_incident
from rescue_incident_store import history_text as sqlite_fall_history
from rescue_incident_store import get_incident, history_text, initialize
initialize()

import json
import re
import sqlite3
import sys
from contextlib import closing
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "rescue_incidents.sqlite3"
STATUS_KEY = re.compile(r"rescueDrone\.(reviewed|simulatedEms)\.[a-f0-9]{32}")
PORT = int(sys.argv[1])
ORIGIN = f"http://127.0.0.1:{PORT}"

with closing(sqlite3.connect(DB)) as db, db:
    db.execute("""CREATE TABLE IF NOT EXISTS incident_status (
        key TEXT PRIMARY KEY,
        value TEXT
    )""")


class Dispatcher(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_json(self, value):
        body = json.dumps(value).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.split("?", 1)[0] == "/api/incident-ai":
            incident_ai(self, ORIGIN, start=False)
            return
        request_path = urlsplit(self.path).path

        if request_path in ("/api/fall-review-history", "/fall_incident_history.jsonl"):
            body = sqlite_fall_history().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-RescueDrone-History", "sqlite")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if request_path == "/api/sources":
            try:
                self.send_json(latest_sources())
            except sqlite3.Error:
                self.send_error(503, "Source telemetry unavailable")
            return

        if request_path == "/api/incident-status":
            with closing(sqlite3.connect(DB)) as db:
                rows = dict(db.execute("SELECT key, value FROM incident_status"))
            self.send_json(rows)
            return

        if request_path == "/cliff_track_alert.json":
            try:
                pointer = json.loads(
                    (ROOT / "cliff_track_alert.json").read_text(encoding="utf-8-sig")
                )
            except (FileNotFoundError, json.JSONDecodeError):
                pointer = {}
            record = sqlite_get_incident(pointer.get("run_id"))
            if record is not None:
                self.send_json(record)
                return

        super().do_GET()

    def do_POST(self):
        if self.path == "/api/agency-reference/refresh":
            if self.headers.get("Origin") != ORIGIN:
                self.send_error(403)
                return
            key = os.environ.get("RESCUEDRONE_TINYFISH_KEY")
            if not key:
                self.send_error(503, "Restart the dispatcher with a TinyFish key")
                return

            source = "https://www.tempe.gov/government/fire-medical-rescue/about-fire-medical-rescue"
            body = json.dumps({
                "url": source,
                "goal": "Read only this public page. Return JSON with agency_name and "
                        "service_types (an array of strings). Extract only explicitly listed services.",
            }).encode("utf-8")
            request = Request(
                "https://agent.tinyfish.ai/v1/automation/run-sse",
                data=body,
                headers={"X-API-Key": key, "Content-Type": "application/json"},
                method="POST",
            )
            try:
                with urlopen(request, timeout=120) as response:
                    for line in response:
                        if not line.startswith(b"data:"):
                            continue
                        event = json.loads(line[5:])
                        if event.get("type") != "COMPLETE":
                            continue
                        result = event.get("result")
                        if event.get("status") != "COMPLETED" or not isinstance(result, dict):
                            break
                        name = result.get("agency_name")
                        services = result.get("service_types")
                        if (isinstance(name, str) and name.strip()
                                and isinstance(services, list) and services
                                and all(isinstance(item, str) and item.strip() for item in services)):
                            self.send_json({"agency_name": name, "service_types": services,
                                            "source_url": source})
                            return
                        break
            except HTTPError as error:
                self.send_error(502, f"TinyFish returned HTTP {error.code}")
                return
            except (URLError, TimeoutError, ValueError):
                self.send_error(502, "TinyFish request failed")
                return
            self.send_error(502, "TinyFish did not return a usable agency record")
            return

        if self.path.split("?", 1)[0] == "/api/incident-ai":
            incident_ai(self, ORIGIN, start=True)
            return
        if self.path != "/api/incident-status":
            self.send_error(404)
            return
        if self.headers.get("Origin") != ORIGIN:
            self.send_error(403)
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 65536:
                raise ValueError
            data = json.loads(self.rfile.read(length))
            entries = data["entries"]
            if not isinstance(entries, dict):
                raise ValueError
            for key, value in entries.items():
                if not STATUS_KEY.fullmatch(key):
                    raise ValueError
                if value is not None and (not isinstance(value, str) or len(value) > 64):
                    raise ValueError
        except (ValueError, TypeError, KeyError):
            self.send_error(400, "Invalid incident status")
            return

        with closing(sqlite3.connect(DB)) as db, db:
            if data.get("import") is True:
                db.executemany(
                    "INSERT OR IGNORE INTO incident_status VALUES (?, ?)",
                    entries.items(),
                )
            else:
                db.executemany(
                    """INSERT INTO incident_status VALUES (?, ?)
                       ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
                    entries.items(),
                )

        self.send_json({"ok": True})


print(f"RescueDrone dispatcher: {ORIGIN}/dispatcher_test.html", flush=True)
ThreadingHTTPServer(("127.0.0.1", PORT), Dispatcher).serve_forever()
