[CmdletBinding()]
param(
    [string]$ProjectPath = (Join-Path $env:USERPROFILE 'RescueDrone'),
    [string]$OutputDirectory = [Environment]::GetFolderPath('Desktop')
)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectPath).Path
if (-not $OutputDirectory) { $OutputDirectory = $root }
if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
    throw "Output folder does not exist: $OutputDirectory"
}

$major = @(
    'rescue_dispatcher_server.py', 'dispatcher_test.html',
    'samsung_live_fall_review.py', 'fall_review_replay.py', 'capture_track_alert.py',
    'samsung_live_viewer.html', 'drone_viewer.html',
    'rescue_incident_store.py', 'rescue_source_telemetry.py', 'rescue_incident_ai.py',
    'gemini_movement_test.py', 'rescue_gemini_audio.py',
    'rescue_demo_pin.py', 'rescue_police_units.py',
    'RescueDrone_ResponderDemo.slx', 'README.md', 'Start-RescueDrone.ps1',
    'Open-RescueDrone.cmd'
)
$optional = @(
    'dispatcher_diagnostics.html', 'simulated_incident.json', 'requirements.txt',
    'rescue_matlab_report.png', 'rescue_two_feed_timeline.png', 'rescue_stateflow_workflow.png'
)

$paths = @()
$missing = @()
foreach ($name in $major + $optional) {
    $item = Join-Path $root $name
    if (-not (Test-Path -LiteralPath $item -PathType Leaf) -and $name -eq 'RescueDrone_ResponderDemo.slx') {
        $matches = @(Get-ChildItem -LiteralPath $root -Recurse -File -Filter $name)
        if ($matches.Count -gt 1) {
            throw 'More than one Simulink model found. Put the intended one in the main RescueDrone folder.'
        }
        if ($matches.Count -eq 1) { $item = $matches[0].FullName }
    }
    if (Test-Path -LiteralPath $item -PathType Leaf) {
        $paths += $item
    } elseif ($major -contains $name) {
        $missing += $name
    }
}

if ($missing.Count) {
    throw ('Missing major files: ' + ($missing -join ', ') + '. No ZIP was created.')
}

$destination = Join-Path $OutputDirectory (
    'RescueDrone_Major_Files_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.zip'
)
Compress-Archive -LiteralPath $paths -DestinationPath $destination -CompressionLevel Optimal
Write-Host "Created: $destination"
Write-Host "Packed $($paths.Count) source, model, launcher, and report files."
