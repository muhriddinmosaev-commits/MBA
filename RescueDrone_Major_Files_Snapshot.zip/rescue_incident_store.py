
import json
import sqlite3
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "rescue_incidents.sqlite3"
HISTORY = ROOT / "fall_incident_history.jsonl"


def initialize():
    with closing(sqlite3.connect(DB)) as db, db:
        db.execute("""CREATE TABLE IF NOT EXISTS fall_incidents (
            run_id TEXT PRIMARY KEY,
            received_at_utc TEXT NOT NULL,
            payload TEXT NOT NULL
        )""")

        if HISTORY.is_file():
            for number, line in enumerate(HISTORY.read_text(
                encoding="utf-8-sig"
            ).splitlines(), start=1):
                if not line.strip():
                    continue
                record = json.loads(line)
                if not record.get("run_id") or not record.get("received_at_utc"):
                    raise ValueError(f"Missing incident ID or timestamp on history line {number}")
                db.execute(
                    "INSERT OR IGNORE INTO fall_incidents VALUES (?, ?, ?)",
                    (record["run_id"], record["received_at_utc"], json.dumps(record)),
                )


def save_incident(record):
    with closing(sqlite3.connect(DB)) as db, db:
        db.execute(
            "INSERT OR IGNORE INTO fall_incidents VALUES (?, ?, ?)",
            (record["run_id"], record["received_at_utc"], json.dumps(record)),
        )


def history_text():
    with closing(sqlite3.connect(DB)) as db:
        rows = db.execute(
            "SELECT payload FROM fall_incidents ORDER BY received_at_utc, rowid"
        )
        return "".join(payload + "\n" for (payload,) in rows)


def get_incident(run_id):
    with closing(sqlite3.connect(DB)) as db:
        row = db.execute(
            "SELECT payload FROM fall_incidents WHERE run_id = ?", (run_id,)
        ).fetchone()
    return json.loads(row[0]) if row else None
